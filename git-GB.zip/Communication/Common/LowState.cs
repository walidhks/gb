﻿using System;

namespace GbService.Communication.Common
{
	public enum LowState
	{
		Idle,
		Send,
		Receive
	}
}
