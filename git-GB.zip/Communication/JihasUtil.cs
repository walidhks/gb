﻿using System;
using System.Collections.Generic;

namespace GbService.Communication
{
	public class JihasUtil
	{
		public static List<GraphMap> Dict = new List<GraphMap>
		{
			new GraphMap(33, 17, 1, "B_FLHxB_FSC"),
			new GraphMap(33, 17, 2, "RBC-S_FSC"),
			new GraphMap(33, 17, 3, "WBC-S_FSC")
		};
	}
}
