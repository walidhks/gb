﻿using System;

namespace GbService.Communication
{
	public enum Coding
	{
		Asc,
		Utf8,
		Unicode
	}
}
