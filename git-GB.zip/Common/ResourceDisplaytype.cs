﻿using System;

namespace GbService.Common
{
	public enum ResourceDisplaytype
	{
		Generic,
		Domain,
		Server,
		Share,
		File,
		Group,
		Network,
		Root,
		Shareadmin,
		Directory,
		Tree,
		Ndscontainer
	}
}
