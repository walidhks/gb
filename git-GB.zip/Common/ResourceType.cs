﻿using System;

namespace GbService.Common
{
	public enum ResourceType
	{
		Any,
		Disk,
		Print,
		Reserved = 8
	}
}
