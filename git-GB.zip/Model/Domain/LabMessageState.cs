﻿using System;

namespace GbService.Model.Domain
{
	public enum LabMessageState
	{
		Active,
		Annulé,
		Ok
	}
}
