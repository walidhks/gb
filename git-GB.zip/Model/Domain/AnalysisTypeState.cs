﻿using System;

namespace GbService.Model.Domain
{
	public enum AnalysisTypeState
	{
		EnCours,
		Validé,
		NonValidé,
		Supprimé
	}
}
