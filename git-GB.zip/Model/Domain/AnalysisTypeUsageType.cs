﻿using System;

namespace GbService.Model.Domain
{
	public enum AnalysisTypeUsageType
	{
		Analysis,
		Bilan,
		Group,
		AddCommand
	}
}
