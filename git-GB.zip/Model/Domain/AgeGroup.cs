﻿using System;
using System.ComponentModel;

namespace GbService.Model.Domain
{
	public enum AgeGroup
	{
		[Description("Nouveau Né")]
		NouveauNé,
		Enfant,
		Adulte
	}
}
