﻿using System;

namespace GbService.Model.Domain
{
	public enum AnalysisRequestState
	{
		Crée,
		Publiée,
		Bloquée,
		Supprimée,
		Validée,
		Complet
	}
}
