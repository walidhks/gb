﻿using System;

namespace GbService.Model.Domain
{
	public enum SexeEnum
	{
		Masculin,
		Féminin
	}
}
