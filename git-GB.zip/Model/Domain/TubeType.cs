﻿using System;

namespace GbService.Model.Domain
{
	public class TubeType
	{
		public long TubeTypeId { get; set; }

		public string TubeTypeName { get; set; }

		public string Color { get; set; }
	}
}
