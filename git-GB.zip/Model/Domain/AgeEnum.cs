﻿using System;

namespace GbService.Model.Domain
{
	public enum AgeEnum
	{
		Y,
		M,
		D
	}
}
