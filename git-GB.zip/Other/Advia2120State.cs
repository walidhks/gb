﻿using System;

namespace GbService.Other
{
	public enum Advia2120State
	{
		Idle,
		Active,
		Blocked
	}
}
